<?php

namespace App\Http\Controllers;

use App\Exports\CRAReport;
use App\Exports\ERMExport;
use App\Exports\IncidentExport;
use App\Exports\KeyRiskIndicatorRegisterExport;
use App\Exports\QMSExport;
use App\Exports\RiskExport;
use App\Exports\StrategicExport;
use App\Exports\TreatmentPlanExport;
use App\Models\BUNIT1;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;

class ReporController extends Controller
{

    private function getBusinessUnitDetails()
    {

        $businessUnit = Auth::user()->bunit;

        $businessUnitObjectives = BUNIT1::where('BunitID', $businessUnit->id)->get();
        $headerRow = 12 + $businessUnitObjectives->count();

        $data = [
            'businessUnit' => $businessUnit,
            'businessUnitObjectives' => $businessUnitObjectives,
            'headerRow' => $headerRow,
        ];

        return $data;

    }

    public function exportExcel()
    {
        $exportRequiredData = $this->getBusinessUnitDetails();

        return Excel::download(new RiskExport($exportRequiredData), 'RiskRegister.xlsx');

    }

    public function exportKRIRegister()
    {

        $exportRequiredData = $this->getBusinessUnitDetails();

        return Excel::download(new KeyRiskIndicatorRegisterExport($exportRequiredData), 'KRIRegister.xlsx');
    }

    public function exportERMRegister()
    {

        $exportRequiredData = $this->getBusinessUnitDetails();
        return Excel::download(new ERMExport($exportRequiredData), 'ERMRegister.xlsx');
    }

    public function exportQmsRegister()
    {

        $exportRequiredData = $this->getBusinessUnitDetails();

        return Excel::download(new QMSExport($exportRequiredData), 'QmsRegister.xlsx');
    }

    public function exportIncidentRegister()
    {

        $exportRequiredData = $this->getBusinessUnitDetails();

        return Excel::download(new IncidentExport($exportRequiredData), 'Incodemt-Register.xlsx');

    }

    public function exportActionRegister()
    {

        $exportRequiredData = $this->getBusinessUnitDetails();
        return Excel::download(new TreatmentPlanExport($exportRequiredData), 'Action-Register.xlsx');
    }

    public function exportCRMRegister()
    {

        $headerRow = 12;
        $exportRequiredData = [
            'headerRow' => $headerRow,
        ];

        return Excel::download(new CRAReport($exportRequiredData), 'CRA-Register.xlsx');

    }

    public function exportStrategicRegister()
    {

        $headerRow = 12;
        $exportRequiredData = [
            'headerRow' => $headerRow,
        ];

        return Excel::download(new StrategicExport($exportRequiredData), 'CRA-Register.xlsx');

    }
}
