<?php

namespace App\Http\Controllers\API\V1;

use App\Models\User;
use App\Models\ORISK;
use App\Models\RISK4;
use App\Models\RISK5;
use Illuminate\Http\Request;
use App\Models\ActionTracking;
use App\Models\ActionMilestone;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use App\Services\Shared\DocumentsService;
use App\Services\Shared\ApiResponseService;

class ActionTrackingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $CRM_ACTIVITY_OBJTYPE = 42;

        try {
            $RiskID = \Request::get('RiskID');
            $o_k_r_i_id = \Request::get('o_k_r_i_id');

            $data = ActionTracking::with('supervisor', 'users')->latest()
                ->whereHas('users', function ($q) {

                    $user = Auth::user();
                    $q->where('user_id', $user->id);
                })

                ->where(function ($q) use ($o_k_r_i_id) {
                    if ($o_k_r_i_id) {
                        $q->where('o_k_r_i_id', $o_k_r_i_id);
                    }
                })
                ->where('ObjType', '!=', $CRM_ACTIVITY_OBJTYPE)
                ->paginate(100);

            return (new ApiResponseService())
                ->apiSuccessResponseService($data);
        } catch (\Throwable $th) {
            return (new ApiResponseService())->apiFailedResponseService($th->getMessage());
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $ObjType = $request['ObjType'];
    
        $this->validate($request, [
            'Name' => 'required|string',
            'DueDate' => 'required',
            'ObjType' => 'required|numeric',
        ]);
    
        $statusIsRequired = $request['ObjType'] != 19;
    
        if ($statusIsRequired) {
            $this->validate($request, [
                'Status' => 'required',
            ]);
        }
    
        if ($request['ObjType'] == 42) {
            $this->validate($request, [
                'parent_id' => 'required',
            ]);
        }
    
        if ($request['ObjType'] != 42) {
            $this->validate($request, [
                'user_id' => 'required',
                'Description' => 'required',
                'Category' => 'required',
            ]);
        }
    
        if ($request['ObjType'] == 41) {
            $this->validate($request, [
                'o_i_t_m_id' => 'required',
            ]);
        }
    
        if ($request['ObjType'] != 19 && count($request['selectedAssignments']) <= 0) {
            return (new ApiResponseService())->apiFailedResponseService("User Assignments Required");
        }
    
        // if ($request['ObjType'] == 19 && count($request['selectedCauses']) <= 0) {
        //     return (new ApiResponseService())->apiFailedResponseService("Select sources to treat");
        // }
    
        $user = Auth::user();
    
        DB::beginTransaction();
        try {
            $DocNum = (new DocumentsService())->documentNumembering($request['ObjType']);
            $treatment = ActionTracking::create([
                "DocNum" => $DocNum,
                'o_r_i_s_k_id' => $request['RiskID'],
                'o_k_r_i_id' => $request['o_k_r_i_id'],
                'o_i_t_m_id' => $request['o_i_t_m_id'],
                'parent_id' => $request['parent_id'],
                "ObjType" => $request['ObjType'],
                "Source" => $request['Source'],
                "Category" => $request['Category'],
                "DueDate" => $request['DueDate'],
                "Status" => $request['Status'],
                "Name" => $request['Name'],
                "Description" => $request['Description'],
                "Rating" => $request['Rating'],
                'user_id' => $request['user_id'],
                'Budget' => $request['Budget'],
                'UserSign' => $user->id,
            ]);
    
            // Add activities/milestones if provided
            if ($request->has('activities') && is_array($request['activities'])) {
                foreach ($request['activities'] as $activity) {
                    ActionTracking::create([
                        'parent_id' => $treatment->id,
                        'Name' => $activity['name'],
                        'Description' => $activity['description'],
                        'milestone_due_date' => $activity['due_date'],
                        'milestone_status' => 'Pending',
                        'is_milestone' => true,
                        'UserSign' => $user->id,
                        'ObjType' => $request['ObjType'], // Ensure ObjType matches
                    ]);
                }
            }
            if (isset($request->milestones) && is_array($request->milestones)) {
                foreach ($request->milestones as $mile) {
                    $filePath = NULL;
                    if (($mile['attachment']) && $mile['attachment']->isValid()) {
                        $fileName = $mile['attachment']->getClientOriginalName();
                        $mile['attachment']->move(public_path('milestone_attachments'), $fileName);
                        $filePath = 'milestone_attachments/' . $fileName;
                    }
                    ActionMilestone::create([
                        'action_id'     =>  $treatment->id,
                        'milestone_name'=>  $mile['milestone_name'],
                        'due_date'      =>  $mile['due_date'],
                        'status'        =>  $mile['status'],
                        'attachment'    =>  $filePath,
                        'progress'      =>  0,
                        'is_milestone'  =>  true,
                    ]);
                }
            }
    
            // Handle selected causes for ObjType = 19
            if ($request['ObjType'] == 19 && $request['selectedCauses']) {
                foreach ($request['selectedCauses'] as $cause) {
                    $treatment->riskcauses()->attach($cause, ['ObjType' => 6]);
                }
            }
            
            $selectedAssignments = json_decode($request['selectedAssignments'], true);
            // Handle user assignments
            if ( $request['ObjType'] != 42 && is_array($selectedAssignments) ) {
                foreach ($selectedAssignments as $assignment) {
                    $treatment->users()->attach($assignment['id'], ['ObjType' => $ObjType]);
                }
            } elseif ($request['ObjType'] == 42) {
                foreach ($selectedAssignments as $assignment) {
                    $treatment->activityusers()->attach($assignment, ['ObjType' => $ObjType]);
                }
            }
    
            DB::commit();
            return (new ApiResponseService())->apiSuccessResponseService("Treatment and activities created successfully");
        } catch (\Throwable $th) {
            info($th);
            DB::rollback();
            return (new ApiResponseService())->apiFailedResponseService($th->getMessage());
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        try {
            $data = ActionTracking::with('riskevent.item', 'riskcauses')->where('id', $id)->first();
            $data->milestone = ActionMilestone::where('action_id', $id)->get();

            $users = User::get();
            foreach ($users as $key => $value) {
                $value->isSelected = false;
                $check = RISK4::where('action_tracking_id', $id)
                    ->where('user_id', $value->id)->first();
                if ($check) {
                    $value->isSelected = true;
                }
            }
            $data->users = $users;
            return (new ApiResponseService())
                ->apiSuccessResponseService($data);
        } catch (\Throwable $th) {
            return (new ApiResponseService())
                ->apiFailedResponseService($th->getMessage());
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'Name' => 'required|string|min:4,max:191',
            'DueDate' => 'required',
            'user_id' => 'required',
        ]);
    
        DB::beginTransaction();
        try {
            // Update the ActionTracking details
            ActionTracking::where('id', $id)->update([
                "DueDate" => $request['DueDate'],
                "Status" => $request['Status'],
                "Name" => $request['Name'],
                "Description" => $request['Description'],
                "Rating" => $request['Rating'],
                'user_id' => $request['user_id'], // Supervisor
            ]);
    
            // Check if milestones are present in the request
            if (isset($request->milestones) && is_array($request->milestones)) {
                foreach ($request->milestones as $mile) {
                    if (!empty($mile['id']) && !empty($mile['action_id'])) {
                        
                        if (isset($mile['attachment']) && !empty($mile['attachment']) && (gettype($mile['attachment']) === 'object') && $mile['attachment']->isValid()) {
                            $fileName = $mile['attachment']->getClientOriginalName();
                            $mile['attachment']->move(public_path('milestone_attachments'), $fileName);
                            $filePath = 'milestone_attachments/' . $fileName;
                            
                            ActionMilestone::where(['id' => $mile['id'], 'action_id' => $id])->update([
                                'milestone_name' => $mile['milestone_name'],
                                'due_date' => $mile['due_date'],
                                'status' => $mile['status'],
                                'attachment' => $filePath,  // Add attachment file path
                            ]);
                        }
                        else {
                            ActionMilestone::where(['id' => $mile['id'], 'action_id' => $id])->update([
                                'milestone_name' => $mile['milestone_name'],
                                'due_date' => $mile['due_date'],
                                'status' => $mile['status'],
                            ]);
                        }
                    }
                    // Handle creating new milestones
                    else if (empty($mile['id']) && empty($mile['action_id'])) {
                        $filePath = NULL;

                        if (isset($mile['attachment']) && !empty($mile['attachment']) && (gettype($mile['attachment']) === 'object') && $mile['attachment']->isValid()) {
                            $fileName = $mile['attachment']->getClientOriginalName();
                            $mile['attachment']->move(public_path('milestone_attachments'), $fileName);
                            $filePath = 'milestone_attachments/' . $fileName;
                        }

                        ActionMilestone::create([
                            'action_id' => $id,
                            'milestone_name' => $mile['milestone_name'],
                            'due_date' => $mile['due_date'],
                            'status' => $mile['status'],
                            'attachment' => $filePath,  // Store the attachment path for new milestone
                            'progress' => 0,
                            'is_milestone' => true,
                        ]);
                    }
                }
            }
    
            DB::commit();
            return (new ApiResponseService())->apiSuccessResponseService("Updated Successfully");
        } catch (\Throwable $th) {
            DB::rollback();
            return (new ApiResponseService())->apiFailedResponseService($th->getMessage());
        }
    }
    

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function syncRelForAction(Type $var = null)
    {
        $actionID = \Request::get('action_id');
        $ItemID = \Request::get('ItemID');
        $isSelected = \Request::get('isSelected');

        $data = ActionTracking::where('id', $actionID)->first();

        $isTrue = filter_var($isSelected, FILTER_VALIDATE_BOOLEAN);
        if ($isTrue) {
            $data->riskcauses()->attach($ItemID);
            return "Done";
        }
        $data->riskcauses()->detach($ItemID);
    }

    public function getActionTrackingForERM()
    {

        try {
            $RiskID = \Request::get('RiskID');
            $allLevelOneRisks = RISK5::where('parent', $RiskID)->pluck('o_r_i_s_k_id');

            $data = ORISK::with('item')->whereIn('id', $allLevelOneRisks)->get();

            foreach ($data as $key => $val) {
                $val->expand = false;
                $val->items = ActionTracking::with('supervisor', 'users')->latest()
                    ->where('o_r_i_s_k_id', $val->id)
                    ->get();
            }

            return (new ApiResponseService())
                ->apiSuccessResponseService($data);
        } catch (\Throwable $th) {
            return (new ApiResponseService())->apiFailedResponseService($th->getMessage());
        }
    }

    public function getCorruptionPreventionStrategies()
    {
        $CRM_ACTIVITY_OBJTYPE = 42;

        try {
            $RiskID = \Request::get('RiskID');

            $data = ActionTracking::with('supervisor')->latest()
                ->where('o_r_i_s_k_id', $RiskID)
                ->where('ObjType', '!=', $CRM_ACTIVITY_OBJTYPE)
                ->paginate(100);

            return (new ApiResponseService())
                ->apiSuccessResponseService($data);
        } catch (\Throwable $th) {
            return (new ApiResponseService())->apiFailedResponseService($th->getMessage());
        }
    }

    public function updateMilestoneStatus(Request $request, $id)
    {
        // Validate the incoming request
        $request->validate([
            'status' => 'required|string'
        ]);

        // Find the milestone using the ID
        $milestone = ActionTracking::findOrFail($id);

        // Update the milestone status
        $milestone->update(['milestone_status' => $request->status]);

        // Calculate treatment progress
        $treatment = $milestone->parentTreatment; // Ensure parentTreatment is correctly defined in your model

        $completedActivities = $treatment->activities()->where('milestone_status', 'Completed')->count();
        $totalActivities = $treatment->activities()->count();

        // Update the treatment progress percentage
        $treatment->update([
            'progress' => ($totalActivities > 0) ? ($completedActivities / $totalActivities) * 100 : 0
        ]);

        return response()->json(['message' => 'Milestone status updated successfully']);
    }

}
