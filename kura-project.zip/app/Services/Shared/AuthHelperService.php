<?php

namespace App\Services\Shared;

use App\Models\BUNIT;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpKernel\Bundle\Bundle;

class AuthHelperService
{

    public function getBusinessUnitAssigned(int $userId = null): array
    {

        $user_id = $userId ?? Auth::user()->id;

        $userData = User::with('bunit')->where('id', $user_id)->first();


        return BUNIT::whereIn('id', [2, 3, 6])->pluck('id')->toArray();
        return [
            $userData->bunit->id,
        ];
    }
}
