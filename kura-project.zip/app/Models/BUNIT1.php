<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BUNIT1 extends Model
{
    use HasFactory;

    protected $guarded = ['id'];
    protected $table = 'b_u_n_i_t1_s';
}
