<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ITM1 extends Model
{
    use HasFactory;
    protected $guarded = ['id'];
    protected $table = 'i_t_m1_s';

}
