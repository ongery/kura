import Vue from 'vue';

export const RiskVueEventBus = new Vue();
