<template>

    


                  <!--begin::Content-->
                  <div class="flex-grow-1">


<!--begin::Table-->
<div class="table-responsive border-bottom mb-9">
    <table class="table mb-3">
        <thead>
            <tr class="border-bottom fs-6 fw-bolder text-gray-400">
                <th class="min-w-175px pb-2">Description</th>
                <th class="min-w-70px text-end pb-2">Hours</th>
                <th class="min-w-80px text-end pb-2">Rate</th>
                <th class="min-w-100px text-end pb-2">Amount</th>
            </tr>
        </thead>
        <tbody>
            <tr class="fw-bolder text-gray-700 fs-5 text-end">
                <td class="d-flex align-items-center pt-6">
                <i class="fa fa-genderless text-danger fs-2 me-2"></i>Creative Design</td>
                <td class="pt-6">80</td>
                <td class="pt-6">$40.00</td>
                <td class="pt-6 text-dark fw-boldest">$3200.00</td>
            </tr>
            <tr class="fw-bolder text-gray-700 fs-5 text-end">
                <td class="d-flex align-items-center">
                <i class="fa fa-genderless text-success fs-2 me-2"></i>Logo Design</td>
                <td>120</td>
                <td>$40.00</td>
                <td class="fs-5 text-dark fw-boldest">$4800.00</td>
            </tr>
            <tr class="fw-bolder text-gray-700 fs-5 text-end">
                <td class="d-flex align-items-center">
                <i class="fa fa-genderless text-success fs-2 me-2"></i>Web Development</td>
                <td>210</td>
                <td>$60.00</td>
                <td class="fs-5 text-dark fw-boldest">$12600.00</td>
            </tr>
        </tbody>
    </table>
</div>
<!--end::Table-->


</div>
<!--end::Content-->

</template>