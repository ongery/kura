<template>
    


    
    <!--begin::Table widget 1-->
    <div class="card card-flush mb-xxl-10">
    <!--begin::Header-->
    <div class="card-header pt-5">        
        <!--begin::Title-->
        <h3 class="card-title align-items-start flex-column">
            <span class="card-label fw-bold text-dark">Featured Campaigns</span>
            
            <span class="text-gray-400 pt-2 fw-semibold fs-6">75% activity growth</span>
        </h3>
        <!--end::Title-->

        <!--begin::Toolbar-->
        <div class="card-toolbar">            
            <!--begin::Menu-->
            <button class="btn btn-icon btn-color-gray-400 btn-active-color-success justify-content-end" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end" data-kt-menu-overflow="true">                
                <i class="ki-outline ki-dots-square fs-1 text-gray-300 me-n1"></i>                             
            </button>

            
<!--begin::Menu 2-->
<div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-800 menu-state-bg-light-primary fw-semibold w-200px" data-kt-menu="true">
    <!--begin::Menu item-->
    <div class="menu-item px-3">
        <div class="menu-content fs-6 text-dark fw-bold px-3 py-4">Quick Actions</div>
    </div>
    <!--end::Menu item-->

    <!--begin::Menu separator-->
    <div class="separator mb-3 opacity-75"></div>
    <!--end::Menu separator-->

    <!--begin::Menu item-->
    <div class="menu-item px-3">
        <a href="#" class="menu-link px-3">
            New Ticket
        </a>
    </div>
    <!--end::Menu item-->
    
    <!--begin::Menu item-->
    <div class="menu-item px-3">
        <a href="#" class="menu-link px-3">
            New Customer
        </a>
    </div>
    <!--end::Menu item-->

    <!--begin::Menu item-->
    <div class="menu-item px-3" data-kt-menu-trigger="hover" data-kt-menu-placement="right-start">
        <!--begin::Menu item-->
        <a href="#" class="menu-link px-3">
            <span class="menu-title">New Group</span>
            <span class="menu-arrow"></span>
        </a>
        <!--end::Menu item-->

        <!--begin::Menu sub-->
        <div class="menu-sub menu-sub-dropdown w-175px py-4">
            <!--begin::Menu item-->
            <div class="menu-item px-3">
                <a href="#" class="menu-link px-3">
                    Admin Group
                </a>
            </div>
            <!--end::Menu item-->

            <!--begin::Menu item-->
            <div class="menu-item px-3">
                <a href="#" class="menu-link px-3">
                    Staff Group
                </a>
            </div>
            <!--end::Menu item-->

            <!--begin::Menu item-->            
            <div class="menu-item px-3">
                <a href="#" class="menu-link px-3">
                    Member Group
                </a>
            </div>
            <!--end::Menu item-->
        </div>
        <!--end::Menu sub-->
    </div>
    <!--end::Menu item-->

    <!--begin::Menu item-->
    <div class="menu-item px-3">
        <a href="#" class="menu-link px-3">
            New Contact
        </a>
    </div>
    <!--end::Menu item-->

    <!--begin::Menu separator-->
    <div class="separator mt-3 opacity-75"></div>
    <!--end::Menu separator-->

    <!--begin::Menu item-->
    <div class="menu-item px-3">
        <div class="menu-content px-3 py-3">
            <a class="btn btn-primary  btn-sm px-4" href="#">
                Generate Reports
            </a>
        </div>
    </div>
    <!--end::Menu item-->
</div>
<!--end::Menu 2-->
 
            <!--end::Menu-->             
        </div>
        <!--end::Toolbar-->
    </div>
    <!--end::Header-->

    <!--begin::Body-->
    <div class="card-body">       
        <!--begin::Nav-->             
        <ul class="nav nav-pills nav-pills-custom mb-3">
            <!--begin::Item--> 
            <li class="nav-item mb-3 me-3 me-lg-6">
                <!--begin::Link--> 
                <a class="nav-link d-flex justify-content-between flex-column flex-center overflow-hidden active w-80px h-85px py-4" data-bs-toggle="pill" href="#kt_stats_widget_1_tab_1">
                    <!--begin::Icon-->
                    <div class="nav-icon">                                                                                          
                        <img alt="" src="" class=""/>                                                                                         
                    </div>
                    <!--end::Icon-->
                    
                    <!--begin::Subtitle-->
                    <span class="nav-text text-gray-700 fw-bold fs-6 lh-1">
                        Beats
                    </span> 
                    <!--end::Subtitle-->
                    
                    <!--begin::Bullet-->
                    <span class="bullet-custom position-absolute bottom-0 w-100 h-4px bg-primary"></span>
                    <!--end::Bullet-->
                </a>
                <!--end::Link-->
            </li>
            <!--end::Item--> 

            <!--begin::Item--> 
            <li class="nav-item mb-3 me-3 me-lg-6">
                <!--begin::Link-->
                <a class="nav-link d-flex justify-content-between flex-column flex-center overflow-hidden w-80px h-85px py-4" data-bs-toggle="pill" href="#kt_stats_widget_1_tab_2">
                    <!--begin::Icon-->
                    <div class="nav-icon">
                        <img alt="Logo" src="" class="theme-light-show"/>
                        <img alt="Logo" src="" class="theme-dark-show"/>                                                                                                       
                    </div>
                    <!--end::Icon-->

                    <!--begin::Subtitle-->
                    <span class="nav-text text-gray-700 fw-bold fs-6 lh-1">
                        Amazon
                    </span>  
                    <!--end::Subtitle-->  

                    <!--begin::Bullet-->
                    <span class="bullet-custom position-absolute bottom-0 w-100 h-4px bg-primary"></span>
                    <!--end::Bullet-->
                </a>
                <!--end::Link-->
            </li>
            <!--end::Item--> 

            <!--begin::Item--> 
            <li class="nav-item mb-3 me-3 me-lg-6">
                <!--begin::Link-->
                <a class="nav-link d-flex justify-content-between flex-column flex-center overflow-hidden w-80px h-85px py-4" data-bs-toggle="pill" href="#kt_stats_widget_1_tab_3">
                    <!--begin::Icon-->
                    <div class="nav-icon">                              
                        <img alt="" src="" class=""/>                                                        
                    </div>
                    <!--end::Icon-->

                    <!--begin::Subtitle-->
                    <span class="nav-text text-gray-600 fw-bold fs-6 lh-1">
                        BP
                    </span>  
                    <!--end::Subtitle-->  

                    <!--begin::Bullet-->
                    <span class="bullet-custom position-absolute bottom-0 w-100 h-4px bg-primary"></span>
                    <!--end::Bullet-->
                </a>
                <!--end::Link-->
            </li>
            <!--end::Item--> 

            <!--begin::Item--> 
            <li class="nav-item mb-3 me-3 me-lg-6">
                <!--begin::Link-->
                <a class="nav-link d-flex justify-content-between flex-column flex-center overflow-hidden w-80px h-85px py-4" 
                data-bs-toggle="pill" href="#kt_stats_widget_1_tab_4">
                    <!--begin::Icon-->
                    <div class="nav-icon">                              
                        <img alt="" src="" class="nav-icon"/>                                                       
                    </div>
                    <!--end::Icon-->

                    <!--begin::Subtitle-->
                    <span class="nav-text text-gray-600 fw-bold fs-6 lh-1">
                        Slack
                    </span>    
                    <!--end::Subtitle-->

                    <!--begin::Bullet-->
                    <span class="bullet-custom position-absolute bottom-0 w-100 h-4px bg-primary"></span>
                    <!--end::Bullet-->
                </a>
                <!--end::Link-->
            </li>
            <!--end::Item-->

            <!--begin::Item--> 
            <li class="nav-item mb-3">
                <!--begin::Link-->
                <a class="nav-link d-flex flex-center overflow-hidden w-80px h-85px"  data-bs-toggle="modal" data-bs-target="#kt_modal_create_campaign" href="#">
                    <!--begin::Icon-->
                    <div class="nav-icon">                              
                        <i class="ki-outline ki-plus-square fs-2hx text-gray-400"></i>                    </div> 
                    <!--end::Icon-->  
                    
                    <!--begin::Bullet-->
                    <span class="bullet-custom position-absolute bottom-0 w-100 h-4px bg-primary"></span>
                    <!--end::Bullet-->
                </a>
                <!--end::Link-->
            </li>
            <!--end::Item-->
        </ul>             
        <!--end::Nav-->

        <!--begin::Tab Content-->
        <div class="tab-content">
                                            <!--begin::Tap pane-->
                <div class="tab-pane fade show active" id="kt_stats_widget_1_tab_1">
                    <!--begin::Table container-->
                    <div class="table-responsive">
                        <!--begin::Table-->
                        <table class="table align-middle gs-0 gy-4 my-0">
                            <!--begin::Table head-->
                            <thead>
                                <tr class="fs-7 fw-bold text-gray-500">                                    
                                    <th class="p-0 min-w-150px d-block pt-3">EMAIL TITLE</th>
                                    <th class="text-end min-w-140px pt-3">STATUS</th>
                                    <th class="pe-0 text-end min-w-120px pt-3">CONVERSION</th>
                                </tr>
                            </thead>
                            <!--end::Table head-->

                            <!--begin::Table body-->
                            <tbody>
                                                                    <tr>                                        
                                        <td>
                                            <a href="#" class="text-gray-800 fw-bold text-hover-success mb-1 fs-6">Best Rated Headsets of 2022</a>                                            
                                        </td>

                                        <td class="text-end">
                                            <span class="badge badge-light-success fs-7 fw-bold">Sent</span>
                                        </td> 

                                        <td class="text-end">
                                            <span class="text-gray-800 fw-bold d-block fs-6">18%(6.4k)</span>                                                                                     
                                        </td>                                                                                
                                    </tr>
                                                                    <tr>                                        
                                        <td>
                                            <a href="#" class="text-gray-800 fw-bold text-hover-success mb-1 fs-6">New Model BS 2000 X</a>                                            
                                        </td>

                                        <td class="text-end">
                                            <span class="badge badge-light-primary fs-7 fw-bold">In Draft</span>
                                        </td> 

                                        <td class="text-end">
                                            <span class="text-gray-800 fw-bold d-block fs-6">0.01%(1)</span>                                                                                     
                                        </td>                                                                                
                                    </tr>
                                                                    <tr>                                        
                                        <td>
                                            <a href="#" class="text-gray-800 fw-bold text-hover-success mb-1 fs-6">2022 Spring Conference by Beats</a>                                            
                                        </td>

                                        <td class="text-end">
                                            <span class="badge badge-light-success fs-7 fw-bold">Sent</span>
                                        </td> 

                                        <td class="text-end">
                                            <span class="text-gray-800 fw-bold d-block fs-6">37%(247)</span>                                                                                     
                                        </td>                                                                                
                                    </tr>
                                                                    <tr>                                        
                                        <td>
                                            <a href="#" class="text-gray-800 fw-bold text-hover-success mb-1 fs-6">Best Headsets Giveaway</a>                                            
                                        </td>

                                        <td class="text-end">
                                            <span class="badge badge-light-warning fs-7 fw-bold">In Queue</span>
                                        </td> 

                                        <td class="text-end">
                                            <span class="text-gray-800 fw-bold d-block fs-6">0%(0)</span>                                                                                     
                                        </td>                                                                                
                                    </tr>
                                                            </tbody>
                            <!--end::Table body-->
                        </table>
                        <!--end::Table-->
                    </div>
                    <!--end::Table container-->
                </div>
                <!--end::Tap pane-->
                                            <!--begin::Tap pane-->
                <div class="tab-pane fade " id="kt_stats_widget_1_tab_2">
                    <!--begin::Table container-->
                    <div class="table-responsive">
                        <!--begin::Table-->
                        <table class="table align-middle gs-0 gy-4 my-0">
                            <!--begin::Table head-->
                            <thead>
                                <tr class="fs-7 fw-bold text-gray-500">                                    
                                    <th class="p-0 min-w-150px d-block pt-3">EMAIL TITLE</th>
                                    <th class="text-end min-w-140px pt-3">STATUS</th>
                                    <th class="pe-0 text-end min-w-120px pt-3">CONVERSION</th>
                                </tr>
                            </thead>
                            <!--end::Table head-->

                            <!--begin::Table body-->
                            <tbody>
                                                                    <tr>                                        
                                        <td>
                                            <a href="#" class="text-gray-800 fw-bold text-hover-success mb-1 fs-6">2022 Spring Conference by Beats</a>                                            
                                        </td>

                                        <td class="text-end">
                                            <span class="badge badge-light-success fs-7 fw-bold">Sent</span>
                                        </td> 

                                        <td class="text-end">
                                            <span class="text-gray-800 fw-bold d-block fs-6">37%(247)</span>                                                                                     
                                        </td>                                                                                
                                    </tr>
                                                                    <tr>                                        
                                        <td>
                                            <a href="#" class="text-gray-800 fw-bold text-hover-success mb-1 fs-6">Best Headsets Giveaway</a>                                            
                                        </td>

                                        <td class="text-end">
                                            <span class="badge badge-light-warning fs-7 fw-bold">In Queue</span>
                                        </td> 

                                        <td class="text-end">
                                            <span class="text-gray-800 fw-bold d-block fs-6">0%(0)</span>                                                                                     
                                        </td>                                                                                
                                    </tr>
                                                                    <tr>                                        
                                        <td>
                                            <a href="#" class="text-gray-800 fw-bold text-hover-success mb-1 fs-6">Best Rated Headsets of 2022</a>                                            
                                        </td>

                                        <td class="text-end">
                                            <span class="badge badge-light-success fs-7 fw-bold">Sent</span>
                                        </td> 

                                        <td class="text-end">
                                            <span class="text-gray-800 fw-bold d-block fs-6">18%(6.4k)</span>                                                                                     
                                        </td>                                                                                
                                    </tr>
                                                                    <tr>                                        
                                        <td>
                                            <a href="#" class="text-gray-800 fw-bold text-hover-success mb-1 fs-6">New Model BS 2000 X</a>                                            
                                        </td>

                                        <td class="text-end">
                                            <span class="badge badge-light-primary fs-7 fw-bold">In Draft</span>
                                        </td> 

                                        <td class="text-end">
                                            <span class="text-gray-800 fw-bold d-block fs-6">0.01%(1)</span>                                                                                     
                                        </td>                                                                                
                                    </tr>
                                                            </tbody>
                            <!--end::Table body-->
                        </table>
                        <!--end::Table-->
                    </div>
                    <!--end::Table container-->
                </div>
                <!--end::Tap pane-->
                                            <!--begin::Tap pane-->
                <div class="tab-pane fade " id="kt_stats_widget_1_tab_3">
                    <!--begin::Table container-->
                    <div class="table-responsive">
                        <!--begin::Table-->
                        <table class="table align-middle gs-0 gy-4 my-0">
                            <!--begin::Table head-->
                            <thead>
                                <tr class="fs-7 fw-bold text-gray-500">                                    
                                    <th class="p-0 min-w-150px d-block pt-3">EMAIL TITLE</th>
                                    <th class="text-end min-w-140px pt-3">STATUS</th>
                                    <th class="pe-0 text-end min-w-120px pt-3">CONVERSION</th>
                                </tr>
                            </thead>
                            <!--end::Table head-->

                            <!--begin::Table body-->
                            <tbody>
                                                                    <tr>                                        
                                        <td>
                                            <a href="#" class="text-gray-800 fw-bold text-hover-success mb-1 fs-6">New Model BS 2000 X</a>                                            
                                        </td>

                                        <td class="text-end">
                                            <span class="badge badge-light-primary fs-7 fw-bold">In Draft</span>
                                        </td> 

                                        <td class="text-end">
                                            <span class="text-gray-800 fw-bold d-block fs-6">0.01%(1)</span>                                                                                     
                                        </td>                                                                                
                                    </tr>
                                                                    <tr>                                        
                                        <td>
                                            <a href="#" class="text-gray-800 fw-bold text-hover-success mb-1 fs-6">Best Rated Headsets of 2022</a>                                            
                                        </td>

                                        <td class="text-end">
                                            <span class="badge badge-light-success fs-7 fw-bold">Sent</span>
                                        </td> 

                                        <td class="text-end">
                                            <span class="text-gray-800 fw-bold d-block fs-6">18%(6.4k)</span>                                                                                     
                                        </td>                                                                                
                                    </tr>
                                                                    <tr>                                        
                                        <td>
                                            <a href="#" class="text-gray-800 fw-bold text-hover-success mb-1 fs-6">2022 Spring Conference by Beats</a>                                            
                                        </td>

                                        <td class="text-end">
                                            <span class="badge badge-light-success fs-7 fw-bold">Sent</span>
                                        </td> 

                                        <td class="text-end">
                                            <span class="text-gray-800 fw-bold d-block fs-6">37%(247)</span>                                                                                     
                                        </td>                                                                                
                                    </tr>
                                                                    <tr>                                        
                                        <td>
                                            <a href="#" class="text-gray-800 fw-bold text-hover-success mb-1 fs-6">Best Headsets Giveaway</a>                                            
                                        </td>

                                        <td class="text-end">
                                            <span class="badge badge-light-warning fs-7 fw-bold">In Queue</span>
                                        </td> 

                                        <td class="text-end">
                                            <span class="text-gray-800 fw-bold d-block fs-6">0%(0)</span>                                                                                     
                                        </td>                                                                                
                                    </tr>
                                                            </tbody>
                            <!--end::Table body-->
                        </table>
                        <!--end::Table-->
                    </div>
                    <!--end::Table container-->
                </div>
                <!--end::Tap pane-->
                                            <!--begin::Tap pane-->
                <div class="tab-pane fade " id="kt_stats_widget_1_tab_4">
                    <!--begin::Table container-->
                    <div class="table-responsive">
                        <!--begin::Table-->
                        <table class="table align-middle gs-0 gy-4 my-0">
                            <!--begin::Table head-->
                            <thead>
                                <tr class="fs-7 fw-bold text-gray-500">                                    
                                    <th class="p-0 min-w-150px d-block pt-3">EMAIL TITLE</th>
                                    <th class="text-end min-w-140px pt-3">STATUS</th>
                                    <th class="pe-0 text-end min-w-120px pt-3">CONVERSION</th>
                                </tr>
                            </thead>
                            <!--end::Table head-->

                            <!--begin::Table body-->
                            <tbody>
                                                                    <tr>                                        
                                        <td>
                                            <a href="#" class="text-gray-800 fw-bold text-hover-success mb-1 fs-6">Best Headsets Giveaway</a>                                            
                                        </td>

                                        <td class="text-end">
                                            <span class="badge badge-light-warning fs-7 fw-bold">In Queue</span>
                                        </td> 

                                        <td class="text-end">
                                            <span class="text-gray-800 fw-bold d-block fs-6">0%(0)</span>                                                                                     
                                        </td>                                                                                
                                    </tr>
                                                                    <tr>                                        
                                        <td>
                                            <a href="#" class="text-gray-800 fw-bold text-hover-success mb-1 fs-6">Best Headsets Giveaway</a>                                            
                                        </td>

                                        <td class="text-end">
                                            <span class="badge badge-light-success fs-7 fw-bold">Sent</span>
                                        </td> 

                                        <td class="text-end">
                                            <span class="text-gray-800 fw-bold d-block fs-6">37%(247)</span>                                                                                     
                                        </td>                                                                                
                                    </tr>
                                                                    <tr>                                        
                                        <td>
                                            <a href="#" class="text-gray-800 fw-bold text-hover-success mb-1 fs-6">Best Rated Headsets of 2022</a>                                            
                                        </td>

                                        <td class="text-end">
                                            <span class="badge badge-light-success fs-7 fw-bold">Sent</span>
                                        </td> 

                                        <td class="text-end">
                                            <span class="text-gray-800 fw-bold d-block fs-6">18%(6.4k)</span>                                                                                     
                                        </td>                                                                                
                                    </tr>
                                                                    <tr>                                        
                                        <td>
                                            <a href="#" class="text-gray-800 fw-bold text-hover-success mb-1 fs-6">New Model BS 2000 X</a>                                            
                                        </td>

                                        <td class="text-end">
                                            <span class="badge badge-light-primary fs-7 fw-bold">In Draft</span>
                                        </td> 

                                        <td class="text-end">
                                            <span class="text-gray-800 fw-bold d-block fs-6">0.01%(1)</span>                                                                                     
                                        </td>                                                                                
                                    </tr>
                                                            </tbody>
                            <!--end::Table body-->
                        </table>
                        <!--end::Table-->
                    </div>
                    <!--end::Table container-->
                </div>
                <!--end::Tap pane-->
                    </div>
        <!--end::Tab Content-->        
    </div>
    <!--end: Card Body-->
</div>
<!--end::Table widget 1-->



</template>