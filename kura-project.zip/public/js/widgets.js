/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./resources/js/widgets.js":
/*!*********************************!*\
  !*** ./resources/js/widgets.js ***!
  \*********************************/
/***/ ((module) => {



// Class definition
var KTWidgets = function () {
  // Charts widgets
  var initChartsWidget1 = function initChartsWidget1() {
    var element = document.getElementById("kt_charts_widget_1_chart");
    var labelColor = KTUtil.getCssVariableValue('--bs-gray-500');
    var borderColor = KTUtil.getCssVariableValue('--bs-gray-200');
    var baseColor = KTUtil.getCssVariableValue('--bs-primary');
    var lightColor = KTUtil.getCssVariableValue('--bs-gray-200');
    if (!element) {
      return;
    }
    var height = parseInt(KTUtil.css(element, 'height'));
    var options = {
      series: [{
        name: 'Net Profit',
        data: [60, 60, 90, 90, 80, 80, 70, 70]
      }],
      chart: {
        fontFamily: 'inherit',
        type: 'area',
        height: 350,
        toolbar: {
          show: false
        }
      },
      plotOptions: {},
      legend: {
        show: false
      },
      dataLabels: {
        enabled: false
      },
      fill: {
        type: 'solid',
        opacity: 1
      },
      stroke: {
        curve: 'smooth',
        show: true,
        width: 3,
        colors: [baseColor]
      },
      xaxis: {
        categories: ['Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep'],
        axisBorder: {
          show: false
        },
        axisTicks: {
          show: false
        },
        labels: {
          style: {
            colors: labelColor,
            fontSize: '12px'
          }
        },
        crosshairs: {
          position: 'front',
          stroke: {
            color: baseColor,
            width: 1,
            dashArray: 3
          }
        },
        tooltip: {
          enabled: true,
          formatter: undefined,
          offsetY: 0,
          style: {
            fontSize: '12px'
          }
        }
      },
      yaxis: {
        labels: {
          style: {
            colors: labelColor,
            fontSize: '12px'
          }
        }
      },
      states: {
        normal: {
          filter: {
            type: 'none',
            value: 0
          }
        },
        hover: {
          filter: {
            type: 'none',
            value: 0
          }
        },
        active: {
          allowMultipleDataPointsSelection: false,
          filter: {
            type: 'none',
            value: 0
          }
        }
      },
      tooltip: {
        style: {
          fontSize: '12px'
        },
        y: {
          formatter: function formatter(val) {
            return "$" + val + " thousands";
          }
        }
      },
      colors: [lightColor],
      grid: {
        borderColor: borderColor,
        strokeDashArray: 4,
        yaxis: {
          lines: {
            show: true
          }
        }
      },
      markers: {
        strokeColor: baseColor,
        strokeWidth: 3
      }
    };
    var chart = new ApexCharts(element, options);
    chart.render();
  };
  var initChartsWidget2 = function initChartsWidget2() {
    var charts = document.querySelectorAll('.charts-widget-2-chart');
    var color;
    var strokeColor;
    var height;
    var labelColor = KTUtil.getCssVariableValue('--bs-gray-500');
    var borderColor = KTUtil.getCssVariableValue('--bs-gray-200');
    var options;
    var chart;
    [].slice.call(charts).map(function (element) {
      height = parseInt(KTUtil.css(element, 'height'));
      var options = {
        series: [{
          name: 'Net Profit',
          data: [35, 65, 75, 55, 45, 60, 55]
        }, {
          name: 'Revenue',
          data: [40, 70, 80, 60, 50, 65, 60]
        }],
        chart: {
          fontFamily: 'inherit',
          type: 'bar',
          height: height,
          toolbar: {
            show: false
          },
          sparkline: {
            enabled: true
          }
        },
        plotOptions: {
          bar: {
            horizontal: false,
            columnWidth: ['30%'],
            borderRadius: 4
          }
        },
        legend: {
          show: false
        },
        dataLabels: {
          enabled: false
        },
        stroke: {
          show: true,
          width: 1,
          colors: ['transparent']
        },
        xaxis: {
          categories: ['Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
          axisBorder: {
            show: false
          },
          axisTicks: {
            show: false
          },
          labels: {
            style: {
              colors: labelColor,
              fontSize: '12px'
            }
          }
        },
        yaxis: {
          min: 0,
          max: 100,
          labels: {
            style: {
              colors: labelColor,
              fontSize: '12px'
            }
          }
        },
        fill: {
          type: ['solid', 'solid'],
          opacity: [0.25, 1]
        },
        states: {
          normal: {
            filter: {
              type: 'none',
              value: 0
            }
          },
          hover: {
            filter: {
              type: 'none',
              value: 0
            }
          },
          active: {
            allowMultipleDataPointsSelection: false,
            filter: {
              type: 'none',
              value: 0
            }
          }
        },
        tooltip: {
          style: {
            fontSize: '12px'
          },
          y: {
            formatter: function formatter(val) {
              return "$" + val + " thousands";
            }
          },
          marker: {
            show: false
          }
        },
        colors: ['#ffffff', '#ffffff'],
        grid: {
          borderColor: borderColor,
          strokeDashArray: 4,
          yaxis: {
            lines: {
              show: true
            }
          },
          padding: {
            left: 20,
            right: 20
          }
        }
      };
      var chart = new ApexCharts(element, options);
      chart.render();
    });
  };

  // Follow button
  var initUserFollowButton = function initUserFollowButton() {
    var follow = document.querySelector('#kt_user_follow_button');
    if (follow) {
      follow.addEventListener('click', function (e) {
        // Prevent default action 
        e.preventDefault();

        // Show indicator
        follow.setAttribute('data-kt-indicator', 'on');

        // Disable button to avoid multiple click 
        follow.disabled = true;

        // Check button state
        if (follow.classList.contains("btn-success")) {
          setTimeout(function () {
            follow.removeAttribute('data-kt-indicator');
            follow.classList.remove("btn-success");
            follow.classList.add("btn-light");
            follow.querySelector(".svg-icon").classList.add("d-none");
            follow.querySelector(".indicator-label").innerHTML = 'Follow';
            follow.disabled = false;
          }, 1500);
        } else {
          setTimeout(function () {
            follow.removeAttribute('data-kt-indicator');
            follow.classList.add("btn-success");
            follow.classList.remove("btn-light");
            follow.querySelector(".svg-icon").classList.remove("d-none");
            follow.querySelector(".indicator-label").innerHTML = 'Following';
            follow.disabled = false;
          }, 1000);
        }
      });
    }
  };

  // Calendar
  var initCalendarWidget1 = function initCalendarWidget1() {
    if (typeof FullCalendar === 'undefined' || !document.querySelector('#kt_calendar_widget_1')) {
      return;
    }
    var todayDate = moment().startOf('day');
    var YM = todayDate.format('YYYY-MM');
    var YESTERDAY = todayDate.clone().subtract(1, 'day').format('YYYY-MM-DD');
    var TODAY = todayDate.format('YYYY-MM-DD');
    var TOMORROW = todayDate.clone().add(1, 'day').format('YYYY-MM-DD');
    var calendarEl = document.getElementById('kt_calendar_widget_1');
    var calendar = new FullCalendar.Calendar(calendarEl, {
      headerToolbar: {
        left: 'prev,next today',
        center: 'title',
        right: 'dayGridMonth,timeGridWeek,timeGridDay,listMonth'
      },
      height: 800,
      contentHeight: 780,
      aspectRatio: 3,
      // see: https://fullcalendar.io/docs/aspectRatio

      nowIndicator: true,
      now: TODAY + 'T09:25:00',
      // just for demo

      views: {
        dayGridMonth: {
          buttonText: 'month'
        },
        timeGridWeek: {
          buttonText: 'week'
        },
        timeGridDay: {
          buttonText: 'day'
        }
      },
      initialView: 'dayGridMonth',
      initialDate: TODAY,
      editable: true,
      dayMaxEvents: true,
      // allow "more" link when too many events
      navLinks: true,
      events: [{
        title: 'All Day Event',
        start: YM + '-01',
        description: 'Toto lorem ipsum dolor sit incid idunt ut',
        className: "fc-event-danger fc-event-solid-warning"
      }, {
        title: 'Reporting',
        start: YM + '-14T13:30:00',
        description: 'Lorem ipsum dolor incid idunt ut labore',
        end: YM + '-14',
        className: "fc-event-success"
      }, {
        title: 'Company Trip',
        start: YM + '-02',
        description: 'Lorem ipsum dolor sit tempor incid',
        end: YM + '-03',
        className: "fc-event-primary"
      }, {
        title: 'ICT Expo 2017 - Product Release',
        start: YM + '-03',
        description: 'Lorem ipsum dolor sit tempor inci',
        end: YM + '-05',
        className: "fc-event-light fc-event-solid-primary"
      }, {
        title: 'Dinner',
        start: YM + '-12',
        description: 'Lorem ipsum dolor sit amet, conse ctetur',
        end: YM + '-10'
      }, {
        id: 999,
        title: 'Repeating Event',
        start: YM + '-09T16:00:00',
        description: 'Lorem ipsum dolor sit ncididunt ut labore',
        className: "fc-event-danger"
      }, {
        id: 1000,
        title: 'Repeating Event',
        description: 'Lorem ipsum dolor sit amet, labore',
        start: YM + '-16T16:00:00'
      }, {
        title: 'Conference',
        start: YESTERDAY,
        end: TOMORROW,
        description: 'Lorem ipsum dolor eius mod tempor labore',
        className: "fc-event-primary"
      }, {
        title: 'Meeting',
        start: TODAY + 'T10:30:00',
        end: TODAY + 'T12:30:00',
        description: 'Lorem ipsum dolor eiu idunt ut labore'
      }, {
        title: 'Lunch',
        start: TODAY + 'T12:00:00',
        className: "fc-event-info",
        description: 'Lorem ipsum dolor sit amet, ut labore'
      }, {
        title: 'Meeting',
        start: TODAY + 'T14:30:00',
        className: "fc-event-warning",
        description: 'Lorem ipsum conse ctetur adipi scing'
      }, {
        title: 'Happy Hour',
        start: TODAY + 'T17:30:00',
        className: "fc-event-info",
        description: 'Lorem ipsum dolor sit amet, conse ctetur'
      }, {
        title: 'Dinner',
        start: TOMORROW + 'T05:00:00',
        className: "fc-event-solid-danger fc-event-light",
        description: 'Lorem ipsum dolor sit ctetur adipi scing'
      }, {
        title: 'Birthday Party',
        start: TOMORROW + 'T07:00:00',
        className: "fc-event-primary",
        description: 'Lorem ipsum dolor sit amet, scing'
      }, {
        title: 'Click for Google',
        url: 'http://google.com/',
        start: YM + '-28',
        className: "fc-event-solid-info fc-event-light",
        description: 'Lorem ipsum dolor sit amet, labore'
      }]
    });
    calendar.render();
  };

  // Daterangepicker
  var initDaterangepicker = function initDaterangepicker() {
    if (!document.querySelector('#kt_dashboard_daterangepicker')) {
      return;
    }
    var picker = $('#kt_dashboard_daterangepicker');
    var start = moment();
    var end = moment();
    function cb(start, end, label) {
      var title = '';
      var range = '';
      if (end - start < 100 || label == 'Today') {
        title = 'Today:';
        range = start.format('MMM D');
      } else if (label == 'Yesterday') {
        title = 'Yesterday:';
        range = start.format('MMM D');
      } else {
        range = start.format('MMM D') + ' - ' + end.format('MMM D');
      }
      $('#kt_dashboard_daterangepicker_date').html(range);
      $('#kt_dashboard_daterangepicker_title').html(title);
    }
    picker.daterangepicker({
      direction: KTUtil.isRTL(),
      startDate: start,
      endDate: end,
      opens: 'left',
      applyClass: 'btn-primary',
      cancelClass: 'btn-light-primary',
      ranges: {
        'Today': [moment(), moment()],
        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
        'This Month': [moment().startOf('month'), moment().endOf('month')],
        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
      }
    }, cb);
    cb(start, end, '');
  };
  var initDarkModeToggle = function initDarkModeToggle() {
    var toggle = document.querySelector('#kt_user_menu_dark_mode_toggle');
    if (toggle) {
      toggle.addEventListener('click', function () {
        window.location.href = this.getAttribute('data-kt-url');
      });
    }
  };

  // Public methods
  return {
    init: function init() {
      // Daterangepicker
      initDaterangepicker();

      // Dark Mode
      initDarkModeToggle();

      // Charts widgets
      initChartsWidget1();
      initChartsWidget2();

      // Follow button
      initUserFollowButton();

      // Calendar
      initCalendarWidget1();
    }
  };
}();

// Webpack support
if (true) {
  module.exports = KTWidgets;
}

// On document ready
KTUtil.onDOMContentLoaded(function () {
  KTWidgets.init();
});

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__("./resources/js/widgets.js");
/******/ 	
/******/ })()
;